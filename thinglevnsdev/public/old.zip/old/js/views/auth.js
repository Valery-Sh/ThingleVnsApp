define(function(require){
    var html = require('text!tpl/auth.html');
    
    var view = Backbone.View.extend({
        authCallbacks: function() {
            var self = this;
            return {
                success: function(model) {
                    model.authenticated = true;
                    self.showWelcome();
                    App.authenticated();
                },
                error: function(model, response) {
                    if (response.status == 401) model.authenticated = false;
                    self.showWelcome();
                }
            };
        },
        
        el: 'section#auth',
        template: _.template(html),
        
        authTpl: 'Good to see you again, <%= user.get(\'firstName\') %>',
        notAuthTpl: 'Welcome here! You\'d better to <a href="javascript:void(0)" class="login-btn">login</a>',
        welcomeEl: '#welcome',
        
        events: {
            'click .login-btn': 'login'
        },
        
        login: function() {
            var self = this;
            FB.login(function(response) {
                App.currentUser.save('access_token', response.authResponse.accessToken, self.authCallbacks());
            });
        },
        
        showWelcome: function() {
            var tpl = _.template(App.currentUser.authenticated ? this.authTpl : this.notAuthTpl);
            
            $(this.welcomeEl).html(tpl({
                user: App.currentUser
            }));
        },
        
        initialize: function() {
            App.currentUser.fetch(this.authCallbacks());
        },
        
        render: function() {
            $(this.el).html(this.template({
                fb_app_id: App.Config.get('fbId'),
                channel_file: App.Helpers.staticURL('channel.html')
            }));
            this.showWelcome();
        },
        
    });
    
    
    return view;
});
define(function(require) {
    require('lib/jquery.form');

    var html = require('text!tpl/bookmarklet/index.html');

    return Backbone.View.extend({
        auth: true,

        id: 'bookmarklet',

        template: _.template(html),

        render: function() {
            $(this.el).html(this.template());
        }
    });
});
define(function(require){
    var html = require('text!tpl/things/index.html'),
        Things = Backbone.Collection.extend({
            model: App.Models.Thing,
            url: '/api/things'
        }); 
    
    return Backbone.View.extend({
        id: 'things-list',
        template: _.template(html),
        
        initialize: function() {
            this.things = new Things();  
        },
        
        render: function() {
            var self = this;
            
            this.things.fetch({
                success: function(collection){
                    $(self.el).html(self.template({
                        rows: collection.models
                    }));
                }
            });
        }
    });
});
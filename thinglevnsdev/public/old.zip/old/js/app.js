require.config({
    baseUrl: '/js',
    paths: {
        'text': 'lib/text'
    }
});

var App = {};

App.authCallbacks = [];

App.authenticated = function() {
    for (var i in App.authCallbacks) {
        if (typeof App.authCallbacks[i] == 'function') App.authCallbacks[i]();
    }
};

App.view = function(view) {
    require(['views/' + view], function(View){
        var view = new View(),
            render = function() {
                view.render();
                if ($(view.el).parents().length === 0) {
                    $('section#main').empty().append($(view.el));
                }
            };
        
        
        if (view.auth && !App.currentUser.authenticated) {
            App.authCallbacks.push(render);
        }
        else render();
    });
};

App.yieldContent = function(content) {
    $('#main').empty().html(content);
};

App.init = function() {
    var Config = Backbone.Model.extend({
            url: '/api/config'
        }),
        CurrentUser = Backbone.Model.extend({
            url: '/api/session'
        });
    
    App.Config = new Config();
    App.Config.fetch();
    
    require(['helpers', 'models'], function(helpers, models) {
        App.Helpers = helpers;
        App.Models = models;
    });
    
    App.currentUser = new CurrentUser();
    
    App.view('auth');
};

App.Router = Backbone.Router.extend({
    routes: {
        '': 'list_things',
        'things/new': 'new_thing',
        'bookmarklet': 'bookmarklet'
    },
    
    new_thing: function() {App.view('things/new')},
    list_things: function() {App.view('things/index')},
    bookmarklet: function() {App.view('bookmarklet/index')},
});





$(document).ready(function() {
    App.init();
    new App.Router();
    Backbone.history.start();
})
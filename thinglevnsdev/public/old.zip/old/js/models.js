define(function() {
    return {
        Thing: Backbone.Model.extend({
            url: '/api/things',
            
            pictureURL: function(num, size) {
                if (typeof num == 'undefined') num = 0;
                if (typeof size == 'undefined') size = 'medium';
                
                var picture;
                if (typeof num == 'number') picture = this.get('pictures')[num]
                else picture = num;
                
                return _.find(picture.sizes, function(variant) {return variant.name == size}).url;
            },
            
            coverURL: function(size) {
                var picture = _.each(this.get('pictures'), function(picture){return picture.isCover == true});
                if (!picture) picture = 0;
                
                return this.pictureURL(picture, size)
            }
        })
    };
});
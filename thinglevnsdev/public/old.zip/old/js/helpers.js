define(function(){
    return {
        baseURL: document.location.protocol + '//' + document.location.host + document.location.pathname,
        
        staticURL: function(path) {
            return this.baseURL + '/' + path;
        }
    };
});